package com.hantixray.detection;

import com.hantixray.HantiXray;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import java.util.logging.Logger;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class DetectionManager {
    
    private final HantiXray plugin;
    private final Logger logger;
    private final Map<UUID, Integer> suspicionScores = new HashMap<>();
    
    // Ban message
    private static final String BAN_MESSAGE = "§cX-Ray hack usage detected. This action was performed automatically.\n"
            + "§7If you believe you were banned unfairly, you can appeal on the server forum.";
    
    public DetectionManager(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }
    
    /**
     * Called when a player mines a fake ore
     * @param player Suspicious player
     * @param location Block location
     * @param oreType Ore type
     */
    public void handleFakeOreMined(Player player, Location location, String oreType) {
        UUID playerUuid = player.getUniqueId();
        
        // Asenkron olarak tespit kaydet ve şüphe puanını artır
        plugin.getDatabaseManager().saveDetectionAsync(
                playerUuid,
                location.getBlockX(),
                location.getBlockY(),
                location.getBlockZ(),
                location.getWorld().getName(),
                oreType
        );
        
        plugin.getDatabaseManager().increaseSuspicionScoreAsync(playerUuid, 1, newScore -> {
        suspicionScores.put(playerUuid, newScore);
        
            // Webhook bildirimi asenkron
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
        plugin.getWebhookManager().sendSuspiciousActivityAlert(player, location, oreType, newScore);
            });
        
        logger.info("Suspicious activity detected: " + player.getName() + " mined a fake " + oreType + 
                ". Suspicion score: " + newScore);
        
            // Ban işlemi ana thread'de
        int threshold = plugin.getConfigManager().getSuspicionThreshold();
        if (newScore >= threshold) {
            banPlayer(player, newScore);
        }
        });
    }
    
    /**
     * Get player's suspicion score (from memory or database)
     * @param playerUuid Player UUID
     * @return Suspicion score
     */
    public int getSuspicionScore(UUID playerUuid) {
        if (suspicionScores.containsKey(playerUuid)) {
            return suspicionScores.get(playerUuid);
        } else {
            int score = plugin.getDatabaseManager().getSuspicionScore(playerUuid);
            suspicionScores.put(playerUuid, score);
            return score;
        }
    }
    
    /**
     * Ban a player
     * @param player Player to ban
     * @param suspicionScore Suspicion score
     */
    private void banPlayer(Player player, int suspicionScore) {
        // Run on main thread
        Bukkit.getScheduler().runTask(plugin, () -> {
            UUID playerUuid = player.getUniqueId();
            String playerName = player.getName();
            
            Bukkit.getBanList(BanList.Type.NAME).addBan(
                    playerName,
                    BAN_MESSAGE,
                    null, // Permanent ban
                    "HantiXray"
            );
            
            player.kickPlayer(BAN_MESSAGE);
            
            // Send webhook notification
            plugin.getWebhookManager().sendAutoBanAlert(player, suspicionScore);
            
            // Log
            logger.info(playerName + " (" + playerUuid + ") was automatically banned for using X-Ray hacks. Suspicion score: " + suspicionScore);
            
            // Notify admins
            Bukkit.getOnlinePlayers().stream()
                    .filter(p -> p.hasPermission("hantixray.admin"))
                    .forEach(p -> p.sendMessage("§c[HantiXray] §f" + playerName + 
                            " §cwas automatically banned for using X-Ray hacks. §7(Suspicion score: " + 
                            suspicionScore + "/" + plugin.getConfigManager().getSuspicionThreshold() + ")"));
        });
    }
    
    /**
     * Manually set player's suspicion score
     * @param playerUuid Player UUID
     * @param score New score
     */
    public void setPlayerSuspicionScore(UUID playerUuid, int score) {
        // Create player record if not exists
        Player player = Bukkit.getPlayer(playerUuid);
        if (player != null) {
            plugin.getDatabaseManager().savePlayer(playerUuid, player.getName());
        }
        
        // Update score in database
        try (java.sql.Connection conn = plugin.getDatabaseManager().getConnection();
             java.sql.PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE players SET suspicion_score = ?, last_updated = CURRENT_TIMESTAMP WHERE uuid = ?")) {
            
            stmt.setInt(1, score);
            stmt.setString(2, playerUuid.toString());
            
            stmt.executeUpdate();
            
            // Update in memory
            suspicionScores.put(playerUuid, score);
            
            logger.info("Player " + playerUuid + " suspicion score was manually set to " + score + ".");
        } catch (java.sql.SQLException e) {
            logger.severe("Error setting suspicion score: " + e.getMessage());
        }
    }
} 