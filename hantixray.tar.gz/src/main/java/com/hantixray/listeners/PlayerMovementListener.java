package com.hantixray.listeners;

import com.hantixray.HantiXray;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class PlayerMovementListener implements Listener {
    
    private final HantiXray plugin;
    private final Logger logger;
    
    // Fake mine güncellemeleri için cooldown (throttling)
    private final Map<Player, Long> lastFakeMineUpdate = new HashMap<>();
    private static final long FAKE_MINE_UPDATE_COOLDOWN_MS = 8000; // 2 saniyeden 8 saniyeye çıkarıldı
    
    public PlayerMovementListener(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // Oyuncu veritabanına asenkron kaydedilir
        plugin.getDatabaseManager().savePlayerAsync(player.getUniqueId(), player.getName());
        
        // Oyuncu exempt değilse sahte madenler oluştur
        if (!player.hasPermission("hantixray.exempt") && !player.isOp()) {
            // Kısa bir gecikme ile çalıştır (chunk yükleme için)
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                plugin.getFakeMineManager().refreshFakeMinesForPlayerAsync(player);
                lastFakeMineUpdate.put(player, System.currentTimeMillis());
            }, 20L); // 1 saniye sonra
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Oyuncu çıkış yaptığında sahte madenleri temizle
        plugin.getFakeMineManager().removePlayerFakeMines(player.getUniqueId());
        lastFakeMineUpdate.remove(player);
    }
    
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        // Sadece x/z hareketlerini kontrol et (y için kayma olabilir)
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() && 
                event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }
        
        Player player = event.getPlayer();
        
        // Oyuncu exempt değilse ve önemli bir hareket olduysa sahte madenleri güncelle
        if (!player.hasPermission("hantixray.exempt") && !player.isOp()) {
            long now = System.currentTimeMillis();
            long lastUpdate = lastFakeMineUpdate.getOrDefault(player, 0L);
            if (now - lastUpdate >= FAKE_MINE_UPDATE_COOLDOWN_MS) {
                // Asenkron fake mine güncellemesi
                plugin.getFakeMineManager().refreshFakeMinesForPlayerAsync(player);
                lastFakeMineUpdate.put(player, now);
            }
        }
    }
} 