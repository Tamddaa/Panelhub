package com.hantixray.listeners;

import com.hantixray.HantiXray;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import java.util.logging.Logger;

public class BlockBreakListener implements Listener {
    
    private final HantiXray plugin;
    private final Logger logger;
    
    public BlockBreakListener(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }
    
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        
        // Oyuncu muafsa, kontrol etmeye gerek yok
        if (player.hasPermission("hantixray.exempt") || player.isOp()) {
            return;
        }
        
        // Blok sahte maden mi kontrol et
        if (plugin.getFakeMineManager().isFakeOre(player, block)) {
            // Sahte madenin türünü al
            String oreType = plugin.getFakeMineManager().handleBrokenFakeOre(player, block);
            
            if (oreType != null) {
                // Tespit yöneticisine bildir (asenkron, lag yapmaz)
                plugin.getDetectionManager().handleFakeOreMined(player, block.getLocation(), oreType);
                
                if (plugin.getConfig().getBoolean("debug", false)) {
                    logger.info("Oyuncu " + player.getName() + " sahte " + oreType + " madeni kazdı.");
                }
            }
        }
    }
} 