package com.hantixray.commands;

import com.hantixray.HantiXray;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import java.util.logging.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class MainCommand implements CommandExecutor, TabCompleter {
    
    private final HantiXray plugin;
    private final Logger logger;
    
    private static final List<String> MAIN_COMMANDS = Arrays.asList("reload", "status", "stats", "reset", "exempt", "unexempt");
    
    public MainCommand(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("hantixray.admin")) {
            sender.sendMessage(ChatColor.RED + "Bu komutu kullanma izniniz yok.");
            return true;
        }
        
        if (args.length == 0) {
            sendHelpMessage(sender);
            return true;
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "reload":
                handleReloadCommand(sender);
                break;
            case "status":
                handleStatusCommand(sender);
                break;
            case "stats":
                handleStatsCommand(sender, args);
                break;
            case "reset":
                handleResetCommand(sender, args);
                break;
            case "exempt":
                handleExemptCommand(sender, args, true);
                break;
            case "unexempt":
                handleExemptCommand(sender, args, false);
                break;
            default:
                sendHelpMessage(sender);
                break;
        }
        
        return true;
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) {
            return MAIN_COMMANDS.stream()
                    .filter(c -> c.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        } else if (args.length == 2) {
            String subCommand = args[0].toLowerCase();
            
            if (subCommand.equals("stats") || subCommand.equals("reset") || 
                    subCommand.equals("exempt") || subCommand.equals("unexempt")) {
                
                return Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(name -> name.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            }
        }
        
        return new ArrayList<>();
    }
    
    /**
     * Yardım mesajını gönder
     * @param sender Komut göndericisi
     */
    private void sendHelpMessage(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "==== HantiXray Komutları ====");
        sender.sendMessage(ChatColor.YELLOW + "/hantixray reload" + ChatColor.WHITE + " - Konfigürasyonu yeniden yükle");
        sender.sendMessage(ChatColor.YELLOW + "/hantixray status" + ChatColor.WHITE + " - Plugin durumunu göster");
        sender.sendMessage(ChatColor.YELLOW + "/hantixray stats [oyuncu]" + ChatColor.WHITE + " - Oyuncu şüphe istatistiklerini göster");
        sender.sendMessage(ChatColor.YELLOW + "/hantixray reset <oyuncu>" + ChatColor.WHITE + " - Oyuncunun şüphe puanını sıfırla");
        sender.sendMessage(ChatColor.YELLOW + "/hantixray exempt <oyuncu>" + ChatColor.WHITE + " - Oyuncuyu kontrollerden muaf tut");
        sender.sendMessage(ChatColor.YELLOW + "/hantixray unexempt <oyuncu>" + ChatColor.WHITE + " - Oyuncunun muafiyetini kaldır");
    }
    
    /**
     * Konfigürasyonu yeniden yükleme komutunu işle
     * @param sender Komut göndericisi
     */
    private void handleReloadCommand(CommandSender sender) {
        plugin.getConfigManager().reloadConfig();
        sender.sendMessage(ChatColor.GREEN + "HantiXray konfigürasyonu yeniden yüklendi.");
        logger.info(sender.getName() + " HantiXray konfigürasyonunu yeniden yükledi.");
    }
    
    /**
     * Plugin durumu komutunu işle
     * @param sender Komut göndericisi
     */
    private void handleStatusCommand(CommandSender sender) {
        int onlinePlayers = Bukkit.getOnlinePlayers().size();
        int exemptPlayers = 0;
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.hasPermission("hantixray.exempt")) {
                exemptPlayers++;
            }
        }
        
        sender.sendMessage(ChatColor.GOLD + "==== HantiXray Durumu ====");
        sender.sendMessage(ChatColor.YELLOW + "Aktif Oyuncular: " + ChatColor.WHITE + onlinePlayers);
        sender.sendMessage(ChatColor.YELLOW + "Muaf Oyuncular: " + ChatColor.WHITE + exemptPlayers);
        sender.sendMessage(ChatColor.YELLOW + "Sahte Maden Oranı: " + ChatColor.WHITE + 
                (plugin.getConfigManager().getFakeOreRate() * 100) + "%");
        sender.sendMessage(ChatColor.YELLOW + "Ban Eşiği: " + ChatColor.WHITE + 
                plugin.getConfigManager().getSuspicionThreshold() + " şüphe puanı");
        
        String webhookUrl = plugin.getConfigManager().getDiscordWebhookUrl();
        sender.sendMessage(ChatColor.YELLOW + "Discord Webhook: " + ChatColor.WHITE + 
                (webhookUrl == null || webhookUrl.isEmpty() ? "Yapılandırılmamış" : "Aktif"));
        
        sender.sendMessage(ChatColor.YELLOW + "Veritabanı: " + ChatColor.WHITE + 
                (plugin.getConfigManager().useMySQL() ? "MySQL" : "SQLite"));
    }
    
    /**
     * Oyuncu istatistikleri komutunu işle
     * @param sender Komut göndericisi
     * @param args Komut argümanları
     */
    private void handleStatsCommand(CommandSender sender, String[] args) {
        if (args.length > 1) {
            // Belirli oyuncu için istatistikler
            String playerName = args[1];
            Player target = Bukkit.getPlayer(playerName);
            
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Oyuncu bulunamadı: " + playerName);
                return;
            }
            
            UUID playerUuid = target.getUniqueId();
            int suspicionScore = plugin.getDetectionManager().getSuspicionScore(playerUuid);
            
            sender.sendMessage(ChatColor.GOLD + "==== Oyuncu Şüphe İstatistikleri ====");
            sender.sendMessage(ChatColor.YELLOW + "Oyuncu: " + ChatColor.WHITE + target.getName());
            sender.sendMessage(ChatColor.YELLOW + "Şüphe Puanı: " + ChatColor.WHITE + suspicionScore + "/" + 
                    plugin.getConfigManager().getSuspicionThreshold());
            sender.sendMessage(ChatColor.YELLOW + "Muaf: " + ChatColor.WHITE + 
                    (target.hasPermission("hantixray.exempt") ? "Evet" : "Hayır"));
            
        } else {
            // Tüm oyuncuların genel istatistikleri
            sender.sendMessage(ChatColor.GOLD + "==== Genel Şüphe İstatistikleri ====");
            
            int totalSuspiciousPlayers = 0;
            
            for (Player player : Bukkit.getOnlinePlayers()) {
                UUID playerUuid = player.getUniqueId();
                int score = plugin.getDetectionManager().getSuspicionScore(playerUuid);
                
                if (score > 0) {
                    totalSuspiciousPlayers++;
                    sender.sendMessage(ChatColor.YELLOW + player.getName() + ": " + ChatColor.WHITE + score + " puan");
                }
            }
            
            if (totalSuspiciousPlayers == 0) {
                sender.sendMessage(ChatColor.GREEN + "Şu anda şüpheli oyuncu bulunmuyor.");
            }
        }
    }
    
    /**
     * Oyuncu şüphe puanı sıfırlama komutunu işle
     * @param sender Komut göndericisi
     * @param args Komut argümanları
     */
    private void handleResetCommand(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Kullanım: /hantixray reset <oyuncu>");
            return;
        }
        
        String playerName = args[1];
        Player target = Bukkit.getPlayer(playerName);
        
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Oyuncu bulunamadı: " + playerName);
            return;
        }
        
        UUID playerUuid = target.getUniqueId();
        plugin.getDetectionManager().setPlayerSuspicionScore(playerUuid, 0);
        
        sender.sendMessage(ChatColor.GREEN + target.getName() + " oyuncusunun şüphe puanı sıfırlandı.");
        logger.info(sender.getName() + " " + target.getName() + " oyuncusunun şüphe puanını sıfırladı.");
    }
    
    /**
     * Oyuncu muafiyet komutunu işle
     * @param sender Komut göndericisi
     * @param args Komut argümanları
     * @param exempt Muafiyet ekle (true) veya kaldır (false)
     */
    private void handleExemptCommand(CommandSender sender, String[] args, boolean exempt) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Kullanım: /hantixray " + (exempt ? "exempt" : "unexempt") + " <oyuncu>");
            return;
        }
        
        String playerName = args[1];
        Player target = Bukkit.getPlayer(playerName);
        
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Oyuncu bulunamadı: " + playerName);
            return;
        }
        
        if (exempt) {
            // Muafiyet ekle
            Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), 
                    "lp user " + target.getName() + " permission set hantixray.exempt true");
            
            // Oyuncunun sahte madenlerini temizle
            plugin.getFakeMineManager().removePlayerFakeMines(target.getUniqueId());
            
            sender.sendMessage(ChatColor.GREEN + target.getName() + " artık xray kontrollerinden muaf.");
            logger.info(sender.getName() + " " + target.getName() + " oyuncusunu xray kontrollerinden muaf tuttu.");
        } else {
            // Muafiyeti kaldır
            Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), 
                    "lp user " + target.getName() + " permission unset hantixray.exempt");
            
            sender.sendMessage(ChatColor.GREEN + target.getName() + " artık xray kontrollerine tabi.");
            logger.info(sender.getName() + " " + target.getName() + " oyuncusunun xray kontrolü muafiyetini kaldırdı.");
        }
    }
} 