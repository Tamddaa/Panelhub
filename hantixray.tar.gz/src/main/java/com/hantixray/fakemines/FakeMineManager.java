package com.hantixray.fakemines;

import com.hantixray.HantiXray;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import java.util.logging.Logger;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.concurrent.CompletableFuture;

public class FakeMineManager {
    
    private final HantiXray plugin;
    private final Logger logger;
    private final Random random = new Random();
    
    // Oyuncu UUID -> Sahte madenler listesi
    private final Map<UUID, Map<Location, FakeOre>> fakeMinesMap = new ConcurrentHashMap<>();
    
    // Maden materyalleri
    private static final List<Material> ORE_MATERIALS = Arrays.asList(
            Material.DIAMOND_ORE,
            Material.IRON_ORE,
            Material.GOLD_ORE,
            Material.LAPIS_ORE,
            Material.REDSTONE_ORE,
            Material.EMERALD_ORE,
            // 1.17+ maden türleri
            Material.DEEPSLATE_DIAMOND_ORE,
            Material.DEEPSLATE_IRON_ORE,
            Material.DEEPSLATE_GOLD_ORE,
            Material.DEEPSLATE_LAPIS_ORE,
            Material.DEEPSLATE_REDSTONE_ORE,
            Material.DEEPSLATE_EMERALD_ORE,
            // Nether madenleri
            Material.NETHER_QUARTZ_ORE,
            Material.ANCIENT_DEBRIS,
            Material.NETHER_GOLD_ORE
    );
    
    // Taş materyalleri (sahte maden olarak değiştirilebilir bloklar)
    private static final List<Material> STONE_MATERIALS = Arrays.asList(
            Material.STONE,
            Material.ANDESITE,
            Material.DIORITE,
            Material.GRANITE,
            Material.DEEPSLATE,
            Material.TUFF,
            // Nether taşları
            Material.NETHERRACK,
            Material.BASALT,
            Material.BLACKSTONE
    );
    
    // Overworld madenleri
    private static final List<Material> OVERWORLD_ORES = Arrays.asList(
            Material.DIAMOND_ORE,
            Material.IRON_ORE,
            Material.GOLD_ORE,
            Material.LAPIS_ORE,
            Material.REDSTONE_ORE,
            Material.EMERALD_ORE,
            Material.DEEPSLATE_DIAMOND_ORE,
            Material.DEEPSLATE_IRON_ORE,
            Material.DEEPSLATE_GOLD_ORE,
            Material.DEEPSLATE_LAPIS_ORE,
            Material.DEEPSLATE_REDSTONE_ORE,
            Material.DEEPSLATE_EMERALD_ORE
    );
    // Nether madenleri
    private static final List<Material> NETHER_ORES = Arrays.asList(
            Material.NETHER_QUARTZ_ORE,
            Material.ANCIENT_DEBRIS,
            Material.NETHER_GOLD_ORE
    );
    
    // Oyuncu sayısına göre performans ayarları
    private static final int MAX_FAKE_MINES_PER_PLAYER = 50;
    private static final int MAX_SEARCH_RADIUS = 12; // 15'ten 12'ye düşürüldü
    private static final int MIN_SEARCH_RADIUS = 3;
    
    // Performans için cache
    private final Map<UUID, Long> lastFakeMineGeneration = new ConcurrentHashMap<>();
    private static final long MIN_GENERATION_INTERVAL_MS = 5000; // 5 saniye minimum aralık
    
    public FakeMineManager(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        
        // Düzenli yenileme işlemini kaldır - sadece oyuncu hareketinde tetiklenecek
        // int refreshTicks = plugin.getConfig().getInt("security.refresh-ticks", 40);
        // Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAllFakeMines, refreshTicks, refreshTicks);
    }
    
    /**
     * Tüm oyuncular için sahte madenleri yenile (asenkron)
     */
    public void refreshAllFakeMines() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.hasPermission("hantixray.exempt") && !player.isOp()) {
                    refreshFakeMinesForPlayerAsync(player);
                }
            }
        });
    }
    
    /**
     * Belirli bir oyuncu için sahte madenleri yenile (asenkron)
     */
    public void refreshFakeMinesForPlayerAsync(Player player) {
        // Performans kontrolü
        long now = System.currentTimeMillis();
        long lastGen = lastFakeMineGeneration.getOrDefault(player.getUniqueId(), 0L);
        if (now - lastGen < MIN_GENERATION_INTERVAL_MS) {
            return; // Çok sık üretim yapma
        }
        
        // Oyuncu muaf ise sahte maden oluşturma
        if (player.hasPermission("hantixray.exempt") || player.isOp()) {
            return;
        }
        
        UUID playerUuid = player.getUniqueId();
        
        // Önceki sahte madenleri temizle (ana thread'de)
        cleanupFakeMinesForPlayer(playerUuid);
        
        // Yeni sahte madenleri asenkron oluştur
        createFakeMinesAroundPlayerAsync(player);
        lastFakeMineGeneration.put(playerUuid, now);
    }
    
    /**
     * Oyuncunun etrafında sahte madenler oluştur (asenkron)
     */
    private void createFakeMinesAroundPlayerAsync(Player player) {
        UUID playerUuid = player.getUniqueId();
        World world = player.getWorld();
        Location playerLoc = player.getLocation();
        
        // Oyuncu sayısına göre dinamik ayarlar
        int onlinePlayers = Bukkit.getOnlinePlayers().size();
        int maxDistance = Math.max(MIN_SEARCH_RADIUS, Math.min(MAX_SEARCH_RADIUS, 20 - onlinePlayers));
        int minDistance = MIN_SEARCH_RADIUS;
        
        double fakeOreRate = plugin.getConfigManager().getFakeOreRate();
        
        // Potansiyel blokları daha küçük alanda ara
        List<Block> potentialBlocks = new ArrayList<>();
        int searchRadius = maxDistance;
        
        for (int x = -searchRadius; x <= searchRadius; x += 2) { // 2'şer 2'şer atla
            for (int y = -searchRadius; y <= searchRadius; y += 2) {
                for (int z = -searchRadius; z <= searchRadius; z += 2) {
                    Location loc = playerLoc.clone().add(x, y, z);
                    double distance = loc.distance(playerLoc);
                    if (distance < minDistance || distance > maxDistance) {
                        continue;
                    }
                    Block block = world.getBlockAt(loc);
                    if (STONE_MATERIALS.contains(block.getType()) && isCompletelySurroundedBySolid(block)) {
                        potentialBlocks.add(block);
                        if (potentialBlocks.size() >= MAX_FAKE_MINES_PER_PLAYER * 2) {
                            break; // Yeterli blok bulundu
                        }
                    }
                }
                if (potentialBlocks.size() >= MAX_FAKE_MINES_PER_PLAYER * 2) {
                    break;
                }
            }
            if (potentialBlocks.size() >= MAX_FAKE_MINES_PER_PLAYER * 2) {
                break;
            }
        }
        
        // Sahte madenleri oluştur
        Map<Location, FakeOre> newFakeMines = new HashMap<>();
        List<Material> allowedOres = (world.getEnvironment() == World.Environment.NETHER) ? NETHER_ORES : OVERWORLD_ORES;
        Set<Location> usedLocations = new HashSet<>();
        
        // Daha az damar oluştur
        int maxVeins = Math.min(5, (int) (potentialBlocks.size() * fakeOreRate / 10.0));
        
        for (int v = 0; v < maxVeins && !potentialBlocks.isEmpty(); v++) {
            Block startBlock = potentialBlocks.remove(0);
            int veinSize = Math.min(3, 2 + random.nextInt(3)); // Daha küçük damarlar
            List<Block> veinBlocks = getVeinBlocks(startBlock, veinSize, potentialBlocks, usedLocations);
            
            for (Block b : veinBlocks) {
                if (newFakeMines.size() >= MAX_FAKE_MINES_PER_PLAYER) {
                    break;
                }
                usedLocations.add(b.getLocation());
                Material oreType = allowedOres.get(random.nextInt(allowedOres.size()));
                FakeOre fakeOre = new FakeOre(b.getLocation(), b.getType(), oreType);
                newFakeMines.put(b.getLocation(), fakeOre);
            }
        }
        
        // Ana thread'de blok değişikliklerini uygula
        final Map<Location, FakeOre> finalFakeMines = newFakeMines;
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Map.Entry<Location, FakeOre> entry : finalFakeMines.entrySet()) {
                player.sendBlockChange(entry.getKey(), Bukkit.createBlockData(entry.getValue().getFakeType()));
            }
            fakeMinesMap.put(playerUuid, finalFakeMines);
        });
        
        if (plugin.getConfig().getBoolean("debug", false)) {
            logger.info("Oyuncu " + player.getName() + " için " + newFakeMines.size() + " sahte damar oluşturuldu.");
        }
    }

    // Damar şeklinde blokları bulur (oyundaki gibi komşu bloklardan)
    private List<Block> getVeinBlocks(Block start, int size, List<Block> potentialBlocks, Set<Location> usedLocations) {
        List<Block> vein = new ArrayList<>();
        Queue<Block> queue = new LinkedList<>();
        queue.add(start);
        while (!queue.isEmpty() && vein.size() < size) {
            Block current = queue.poll();
            if (vein.contains(current) || usedLocations.contains(current.getLocation())) continue;
            vein.add(current);
            // Komşu blokları sıraya ekle
            for (Block neighbor : getAdjacentBlocks(current, potentialBlocks, usedLocations)) {
                if (!vein.contains(neighbor) && !usedLocations.contains(neighbor.getLocation())) {
                    queue.add(neighbor);
                }
            }
        }
        return vein;
    }
    // Komşu blokları döndürür
    private List<Block> getAdjacentBlocks(Block block, List<Block> potentialBlocks, Set<Location> usedLocations) {
        List<Block> neighbors = new ArrayList<>();
        int[][] directions = { {1,0,0}, {-1,0,0}, {0,1,0}, {0,-1,0}, {0,0,1}, {0,0,-1} };
        for (int[] dir : directions) {
            Block neighbor = block.getWorld().getBlockAt(
                block.getX() + dir[0],
                block.getY() + dir[1],
                block.getZ() + dir[2]
            );
            if (potentialBlocks.contains(neighbor) && !usedLocations.contains(neighbor.getLocation())) {
                neighbors.add(neighbor);
            }
        }
        return neighbors;
    }
    
    /**
     * Dağılım ağırlıklarına göre rastgele bir maden türü seç
     * @param oreDistribution Maden dağılım ağırlıkları
     * @return Seçilen maden tipi
     */
    private Material selectRandomOreMaterial(Map<String, Double> oreDistribution, List<Material> allowedOres) {
        // allowedOres'te olmayan madenleri filtrele
        Map<String, Double> filteredDistribution = new HashMap<>();
        for (Map.Entry<String, Double> entry : oreDistribution.entrySet()) {
            try {
                Material mat = Material.valueOf(entry.getKey());
                if (allowedOres.contains(mat)) {
                    filteredDistribution.put(entry.getKey(), entry.getValue());
                }
            } catch (IllegalArgumentException ignored) {}
        }
        if (filteredDistribution.isEmpty()) {
            // Hiçbiri yoksa default olarak ilk allowedOres'ten birini döndür
            return allowedOres.get(0);
        }
        double totalWeight = filteredDistribution.values().stream().mapToDouble(Double::doubleValue).sum();
        double randomValue = random.nextDouble() * totalWeight;
        double currentWeight = 0.0;
        for (Map.Entry<String, Double> entry : filteredDistribution.entrySet()) {
            currentWeight += entry.getValue();
            if (randomValue <= currentWeight) {
                String oreName = entry.getKey();
                try {
                    return Material.valueOf(oreName);
                } catch (IllegalArgumentException ignored) {}
            }
        }
        return allowedOres.get(0);
    }
    
    /**
     * Bir oyuncu için tüm sahte madenleri temizle
     * @param playerUuid Oyuncu UUID'si
     */
    private void cleanupFakeMinesForPlayer(UUID playerUuid) {
        // Oyuncu için sahte maden haritasını al
        Map<Location, FakeOre> playerFakeMines = fakeMinesMap.get(playerUuid);
        if (playerFakeMines == null || playerFakeMines.isEmpty()) {
            return;
        }
        
        Player player = Bukkit.getPlayer(playerUuid);
        if (player != null && player.isOnline()) {
            for (FakeOre fakeOre : playerFakeMines.values()) {
                // Gerçek bloğu yeniden göster
                player.sendBlockChange(fakeOre.getLocation(), Bukkit.createBlockData(fakeOre.getOriginalType()));
            }
        }
        
        // Sahte maden haritasını temizle
        fakeMinesMap.put(playerUuid, new HashMap<>());
    }
    
    /**
     * Oyuncu çıkış yaptığında, tüm sahte madenleri temizle
     * @param playerUuid Oyuncu UUID'si
     */
    public void removePlayerFakeMines(UUID playerUuid) {
        cleanupFakeMinesForPlayer(playerUuid);
        fakeMinesMap.remove(playerUuid);
    }
    
    /**
     * Tüm oyuncular için sahte madenleri temizle
     */
    public void cleanupAllFakeMines() {
        for (UUID playerUuid : fakeMinesMap.keySet()) {
            cleanupFakeMinesForPlayer(playerUuid);
        }
        fakeMinesMap.clear();
    }
    
    /**
     * Kırılan bloğun sahte maden olup olmadığını kontrol et
     * @param player Bloğu kıran oyuncu
     * @param block Kırılan blok
     * @return Blok sahte maden ise true, değilse false
     */
    public boolean isFakeOre(Player player, Block block) {
        UUID playerUuid = player.getUniqueId();
        Map<Location, FakeOre> playerFakeMines = fakeMinesMap.get(playerUuid);
        
        if (playerFakeMines == null || playerFakeMines.isEmpty()) {
            return false;
        }
        
        return playerFakeMines.containsKey(block.getLocation());
    }
    
    /**
     * Kırılan sahte madeni işle ve maden türünü döndür
     * @param player Bloğu kıran oyuncu
     * @param block Kırılan blok
     * @return Sahte madenin türü, sahte maden değilse null
     */
    public String handleBrokenFakeOre(Player player, Block block) {
        UUID playerUuid = player.getUniqueId();
        Map<Location, FakeOre> playerFakeMines = fakeMinesMap.get(playerUuid);
        
        if (playerFakeMines == null || playerFakeMines.isEmpty()) {
            return null;
        }
        
        FakeOre fakeOre = playerFakeMines.get(block.getLocation());
        if (fakeOre == null) {
            return null;
        }
        
        // Sahte madeni listeden çıkar
        playerFakeMines.remove(block.getLocation());
        
        // Maden türünü döndür
        return fakeOre.getFakeType().name();
    }
    
    /**
     * İç sınıf: Sahte maden bilgilerini tutar
     */
    private static class FakeOre {
        private final Location location;
        private final Material originalType;
        private final Material fakeType;
        
        public FakeOre(Location location, Material originalType, Material fakeType) {
            this.location = location;
            this.originalType = originalType;
            this.fakeType = fakeType;
        }
        
        public Location getLocation() {
            return location;
        }
        
        public Material getOriginalType() {
            return originalType;
        }
        
        public Material getFakeType() {
            return fakeType;
        }
    }

    // Bir bloğun tüm komşuları katıysa (hava ile teması yoksa) true döndür (optimize edildi)
    private boolean isCompletelySurroundedBySolid(Block block) {
        // Sadece 4 yönü kontrol et (daha hızlı)
        int[][] directions = { {1,0,0}, {-1,0,0}, {0,0,1}, {0,0,-1} };
        for (int[] dir : directions) {
            Block neighbor = block.getWorld().getBlockAt(
                block.getX() + dir[0],
                block.getY() + dir[1],
                block.getZ() + dir[2]
            );
            if (neighbor.getType() == Material.AIR) {
                return false;
            }
        }
        return true;
    }
} 