package com.hantixray;

import com.hantixray.commands.MainCommand;
import com.hantixray.config.ConfigManager;
import com.hantixray.database.DatabaseManager;
import com.hantixray.detection.DetectionManager;
import com.hantixray.fakemines.FakeMineManager;
import com.hantixray.listeners.BlockBreakListener;
import com.hantixray.listeners.PlayerMovementListener;
import com.hantixray.webhook.WebhookManager;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.logging.Logger;

public class HantiXray extends JavaPlugin {
    
    private static HantiXray instance;
    private Logger logger;
    private ConfigManager configManager;
    private DatabaseManager databaseManager;
    private DetectionManager detectionManager;
    private FakeMineManager fakeMineManager;
    private WebhookManager webhookManager;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // Logger başlatma
        logger = getLogger();
        logger.info("HantiXray başlatılıyor...");
        
        // Konfigürasyon yöneticisini başlat
        configManager = new ConfigManager(this);
        configManager.loadConfig();
        
        // Veritabanı bağlantısını oluştur
        databaseManager = new DatabaseManager(this);
        databaseManager.initialize();
        
        // Discord webhook yöneticisini başlat
        webhookManager = new WebhookManager(this);
        
        // Tespit yöneticisini başlat
        detectionManager = new DetectionManager(this);
        
        // Sahte maden yöneticisini başlat
        fakeMineManager = new FakeMineManager(this);
        
        // Komutları kaydet
        getCommand("hantixray").setExecutor(new MainCommand(this));
        
        // Olay dinleyicilerini kaydet
        getServer().getPluginManager().registerEvents(new PlayerMovementListener(this), this);
        getServer().getPluginManager().registerEvents(new BlockBreakListener(this), this);
        
        logger.info("HantiXray başarıyla başlatıldı!");
    }
    
    @Override
    public void onDisable() {
        logger.info("HantiXray kapatılıyor...");
        
        // Veritabanı bağlantısını kapat
        if (databaseManager != null) {
            databaseManager.shutdown();
        }
        
        // Sahte madenleri temizle
        if (fakeMineManager != null) {
            fakeMineManager.cleanupAllFakeMines();
        }
        
        logger.info("HantiXray başarıyla kapatıldı!");
    }
    
    /**
     * Plugin örneğini döndür (Singleton)
     * @return Plugin örneği
     */
    public static HantiXray getInstance() {
        return instance;
    }
    
    /**
     * Konfigürasyon yöneticisini döndür
     * @return Konfigürasyon yöneticisi
     */
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    /**
     * Veritabanı yöneticisini döndür
     * @return Veritabanı yöneticisi
     */
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }
    
    /**
     * Tespit yöneticisini döndür
     * @return Tespit yöneticisi
     */
    public DetectionManager getDetectionManager() {
        return detectionManager;
    }
    
    /**
     * Sahte maden yöneticisini döndür
     * @return Sahte maden yöneticisi
     */
    public FakeMineManager getFakeMineManager() {
        return fakeMineManager;
    }
    
    /**
     * Discord webhook yöneticisini döndür
     * @return Discord webhook yöneticisi
     */
    public WebhookManager getWebhookManager() {
        return webhookManager;
    }
} 