package com.hantixray.database;

import com.hantixray.HantiXray;
import com.hantixray.config.ConfigManager;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.util.logging.Logger;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import java.util.function.Consumer;

public class DatabaseManager {
    
    private final HantiXray plugin;
    private final Logger logger;
    private final ConfigManager configManager;
    private HikariDataSource dataSource;
    
    private static final String CREATE_PLAYERS_TABLE = "CREATE TABLE IF NOT EXISTS players ("
            + "uuid VARCHAR(36) PRIMARY KEY,"
            + "name VARCHAR(16) NOT NULL,"
            + "suspicion_score INT DEFAULT 0,"
            + "last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
            + ")";
    
    // SQLite ve MySQL için ayrı CREATE TABLE ifadeleri
    private static final String CREATE_DETECTIONS_TABLE_MYSQL = "CREATE TABLE IF NOT EXISTS detections ("
            + "id INTEGER PRIMARY KEY AUTO_INCREMENT,"
            + "player_uuid VARCHAR(36) NOT NULL,"
            + "x INT NOT NULL,"
            + "y INT NOT NULL,"
            + "z INT NOT NULL,"
            + "world VARCHAR(64) NOT NULL,"
            + "ore_type VARCHAR(32) NOT NULL,"
            + "detection_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
            + "FOREIGN KEY(player_uuid) REFERENCES players(uuid)"
            + ")";
    
    private static final String CREATE_DETECTIONS_TABLE_SQLITE = "CREATE TABLE IF NOT EXISTS detections ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            + "player_uuid VARCHAR(36) NOT NULL,"
            + "x INT NOT NULL,"
            + "y INT NOT NULL,"
            + "z INT NOT NULL,"
            + "world VARCHAR(64) NOT NULL,"
            + "ore_type VARCHAR(32) NOT NULL,"
            + "detection_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
            + "FOREIGN KEY(player_uuid) REFERENCES players(uuid)"
            + ")";
    
    private String createDetectionsTableSql;
    
    public DatabaseManager(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        this.configManager = plugin.getConfigManager();
    }
    
    /**
     * Veritabanı bağlantısını başlat
     */
    public void initialize() {
        HikariConfig config = new HikariConfig();
        
        if (configManager.useMySQL()) {
            // MySQL bağlantısını yapılandır
            ConfigManager.MySQLConfig mysqlConfig = configManager.getMySQLConfig();
            
            config.setJdbcUrl("jdbc:mysql://" + mysqlConfig.getHost() + ":" + mysqlConfig.getPort() + "/" + mysqlConfig.getDatabase() + "?useSSL=false");
            config.setUsername(mysqlConfig.getUsername());
            config.setPassword(mysqlConfig.getPassword());
            config.setDriverClassName("com.mysql.cj.jdbc.Driver");
            
            // MySQL için CREATE TABLE ifadelerini ayarla
            createDetectionsTableSql = CREATE_DETECTIONS_TABLE_MYSQL;
            
        } else {
            // SQLite bağlantısını yapılandır
            File dbFile = new File(plugin.getDataFolder(), "hantixray.db");
            
            try {
                if (!dbFile.exists()) {
                    dbFile.getParentFile().mkdirs();
                    dbFile.createNewFile();
                }
            } catch (Exception e) {
                logger.severe("SQLite veritabanı dosyası oluşturulamadı: " + e.getMessage());
                return;
            }
            
            config.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
            config.setDriverClassName("org.sqlite.JDBC");
            
            // SQLite için CREATE TABLE ifadelerini ayarla
            createDetectionsTableSql = CREATE_DETECTIONS_TABLE_SQLITE;
        }
        
        // Hikari bağlantı havuzu ayarları
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(5);
        config.setConnectionTimeout(30000);
        config.setIdleTimeout(600000);
        config.setMaxLifetime(1800000);
        config.setLeakDetectionThreshold(60000);
        
        try {
            dataSource = new HikariDataSource(config);
            
            // Tabloları oluştur
            createTables();
            
            logger.info("Veritabanı bağlantısı başarıyla kuruldu (" + (configManager.useMySQL() ? "MySQL" : "SQLite") + ")");
        } catch (Exception e) {
            logger.severe("Veritabanı bağlantısı kurulurken hata oluştu: " + e.getMessage());
        }
    }
    
    /**
     * Gerekli tabloları oluştur
     */
    private void createTables() {
        try (Connection conn = getConnection();
             PreparedStatement playersStmt = conn.prepareStatement(CREATE_PLAYERS_TABLE);
             PreparedStatement detectionsStmt = conn.prepareStatement(createDetectionsTableSql)) {
            
            playersStmt.executeUpdate();
            detectionsStmt.executeUpdate();
            
            logger.info("Veritabanı tabloları başarıyla oluşturuldu/doğrulandı.");
        } catch (SQLException e) {
            logger.severe("Veritabanı tabloları oluşturulurken hata oluştu: " + e.getMessage());
        }
    }
    
    /**
     * Veritabanı bağlantısını al
     * @return JDBC Connection nesnesi
     * @throws SQLException Bağlantı başarısız olduğunda
     */
    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
    
    /**
     * Oyuncuyu veritabanına kaydet veya güncelle
     * @param uuid Oyuncu UUID'si
     * @param name Oyuncu adı
     */
    public void savePlayer(UUID uuid, String name) {
        String query = "INSERT INTO players (uuid, name) VALUES (?, ?) "
                + "ON DUPLICATE KEY UPDATE name = ?, last_updated = CURRENT_TIMESTAMP";
        
        // SQLite için farklı syntax
        if (!configManager.useMySQL()) {
            query = "INSERT OR REPLACE INTO players (uuid, name, last_updated) VALUES (?, ?, CURRENT_TIMESTAMP)";
        }
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, uuid.toString());
            stmt.setString(2, name);
            
            if (configManager.useMySQL()) {
                stmt.setString(3, name);
            }
            
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Oyuncu veritabanına kaydedilirken hata oluştu: " + e.getMessage());
        }
    }
    
    /**
     * Oyuncunun şüphe puanını arttır
     * @param uuid Oyuncu UUID'si
     * @param amount Arttırılacak puan miktarı
     * @return Yeni şüphe puanı
     */
    public int increaseSuspicionScore(UUID uuid, int amount) {
        String query = "UPDATE players SET suspicion_score = suspicion_score + ?, last_updated = CURRENT_TIMESTAMP "
                + "WHERE uuid = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, amount);
            stmt.setString(2, uuid.toString());
            
            stmt.executeUpdate();
            
            // Güncel şüphe puanını al
            return getSuspicionScore(uuid);
        } catch (SQLException e) {
            logger.severe("Şüphe puanı artırılırken hata oluştu: " + e.getMessage());
            return 0;
        }
    }
    
    /**
     * Oyuncunun şüphe puanını al
     * @param uuid Oyuncu UUID'si
     * @return Şüphe puanı
     */
    public int getSuspicionScore(UUID uuid) {
        String query = "SELECT suspicion_score FROM players WHERE uuid = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, uuid.toString());
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("suspicion_score");
                }
            }
        } catch (SQLException e) {
            logger.severe("Şüphe puanı alınırken hata oluştu: " + e.getMessage());
        }
        
        return 0;
    }
    
    /**
     * Tespit olayını veritabanına kaydet
     * @param uuid Oyuncu UUID'si
     * @param x X koordinatı
     * @param y Y koordinatı
     * @param z Z koordinatı
     * @param world Dünya adı
     * @param oreType Maden türü
     */
    public void saveDetection(UUID uuid, int x, int y, int z, String world, String oreType) {
        String query = "INSERT INTO detections (player_uuid, x, y, z, world, ore_type) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, uuid.toString());
            stmt.setInt(2, x);
            stmt.setInt(3, y);
            stmt.setInt(4, z);
            stmt.setString(5, world);
            stmt.setString(6, oreType);
            
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.severe("Tespit kaydedilirken hata oluştu: " + e.getMessage());
        }
    }
    
    /**
     * Bağlantı havuzunu kapat
     */
    public void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            logger.info("Veritabanı bağlantısı kapatıldı.");
        }
    }

    /**
     * Oyuncuyu veritabanına kaydet veya güncelle (asenkron)
     */
    public void savePlayerAsync(UUID uuid, String name) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> savePlayer(uuid, name));
    }

    /**
     * Oyuncunun şüphe puanını arttır (asenkron, callback ile yeni puan döner)
     */
    public void increaseSuspicionScoreAsync(UUID uuid, int amount, Consumer<Integer> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int newScore = increaseSuspicionScore(uuid, amount);
            if (callback != null) {
                callback.accept(newScore);
            }
        });
    }

    /**
     * Oyuncunun şüphe puanını al (asenkron, callback ile döner)
     */
    public void getSuspicionScoreAsync(UUID uuid, Consumer<Integer> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int score = getSuspicionScore(uuid);
            if (callback != null) {
                callback.accept(score);
            }
        });
    }

    /**
     * Tespit olayını veritabanına kaydet (asenkron)
     */
    public void saveDetectionAsync(UUID uuid, int x, int y, int z, String world, String oreType) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveDetection(uuid, x, y, z, world, oreType));
    }
} 