package com.hantixray.config;

import com.hantixray.HantiXray;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.util.logging.Logger;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ConfigManager {
    
    private final HantiXray plugin;
    private final Logger logger;
    private FileConfiguration config;
    private File configFile;
    
    // Varsayılan ayarlar
    private static final double DEFAULT_FAKE_ORE_RATE = 0.5;
    private static final int DEFAULT_SUSPICION_THRESHOLD = 10;
    private static final String DEFAULT_WEBHOOK_URL = "";
    private static final boolean DEFAULT_USE_MYSQL = false;
    private static final String DEFAULT_MYSQL_HOST = "localhost";
    private static final int DEFAULT_MYSQL_PORT = 3306;
    private static final String DEFAULT_MYSQL_DATABASE = "hantixray";
    private static final String DEFAULT_MYSQL_USERNAME = "root";
    private static final String DEFAULT_MYSQL_PASSWORD = "";
    
    // Maden oranları için varsayılan değerler
    private static final Map<String, Double> DEFAULT_ORE_DISTRIBUTION = new HashMap<>() {{
        put("DIAMOND_ORE", 10.0);
        put("IRON_ORE", 30.0);
        put("GOLD_ORE", 20.0);
        put("LAPIS_ORE", 15.0);
        put("REDSTONE_ORE", 15.0);
        put("EMERALD_ORE", 10.0);
    }};
    
    public ConfigManager(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }
    
    /**
     * Konfigürasyonu yükle veya oluştur
     */
    public void loadConfig() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdir();
        }
        
        configFile = new File(plugin.getDataFolder(), "config.yml");
        
        if (!configFile.exists()) {
            plugin.saveResource("config.yml", false);
            logger.info("Varsayılan konfigürasyon dosyası oluşturuldu.");
        }
        
        config = YamlConfiguration.loadConfiguration(configFile);
        
        // Varsayılan değerleri ayarla
        setDefaultValues();
        
        logger.info("Konfigürasyon yüklendi.");
    }
    
    /**
     * Konfigürasyonda olmayan değerler için varsayılanları ayarla
     */
    private void setDefaultValues() {
        boolean updated = false;
        
        // Temel ayarlar
        if (!config.contains("fake-ore-rate")) {
            config.set("fake-ore-rate", DEFAULT_FAKE_ORE_RATE);
            updated = true;
        }
        
        if (!config.contains("suspicion-threshold")) {
            config.set("suspicion-threshold", DEFAULT_SUSPICION_THRESHOLD);
            updated = true;
        }
        
        if (!config.contains("discord-webhook-url")) {
            config.set("discord-webhook-url", DEFAULT_WEBHOOK_URL);
            updated = true;
        }
        
        // Veritabanı ayarları
        if (!config.contains("database.use-mysql")) {
            config.set("database.use-mysql", DEFAULT_USE_MYSQL);
            updated = true;
        }
        
        if (!config.contains("database.mysql.host")) {
            config.set("database.mysql.host", DEFAULT_MYSQL_HOST);
            updated = true;
        }
        
        if (!config.contains("database.mysql.port")) {
            config.set("database.mysql.port", DEFAULT_MYSQL_PORT);
            updated = true;
        }
        
        if (!config.contains("database.mysql.database")) {
            config.set("database.mysql.database", DEFAULT_MYSQL_DATABASE);
            updated = true;
        }
        
        if (!config.contains("database.mysql.username")) {
            config.set("database.mysql.username", DEFAULT_MYSQL_USERNAME);
            updated = true;
        }
        
        if (!config.contains("database.mysql.password")) {
            config.set("database.mysql.password", DEFAULT_MYSQL_PASSWORD);
            updated = true;
        }
        
        // Maden dağılım oranları
        if (!config.contains("ore-distribution")) {
            for (Map.Entry<String, Double> entry : DEFAULT_ORE_DISTRIBUTION.entrySet()) {
                config.set("ore-distribution." + entry.getKey(), entry.getValue());
            }
            updated = true;
        }
        
        // Eğer değişiklik yapıldıysa, dosyayı kaydet
        if (updated) {
            try {
                config.save(configFile);
                logger.info("Konfigürasyon varsayılan değerlerle güncellendi.");
            } catch (IOException e) {
                logger.severe("Konfigürasyon dosyası kaydedilirken hata oluştu: " + e.getMessage());
            }
        }
    }
    
    /**
     * Konfigürasyonu yeniden yükle
     */
    public void reloadConfig() {
        config = YamlConfiguration.loadConfiguration(configFile);
        logger.info("Konfigürasyon yeniden yüklendi.");
    }
    
    /**
     * Konfigürasyonu al
     * @return FileConfiguration nesnesi
     */
    public FileConfiguration getConfig() {
        return config;
    }
    
    /**
     * Sahte maden oranını al
     * @return Sahte maden oranı (0.0 - 1.0 arası)
     */
    public double getFakeOreRate() {
        String protection = config.getString("protection", "trap");
        if (protection.equalsIgnoreCase("full")) {
            return 1.0;
        } else {
            return 0.001;
        }
    }
    
    /**
     * Şüphe eşiğini al
     * @return Şüphe eşiği
     */
    public int getSuspicionThreshold() {
        return config.getInt("suspicion-threshold", DEFAULT_SUSPICION_THRESHOLD);
    }
    
    /**
     * Discord Webhook URL'sini al
     * @return Discord Webhook URL'si
     */
    public String getDiscordWebhookUrl() {
        return config.getString("discord-webhook-url", DEFAULT_WEBHOOK_URL);
    }
    
    /**
     * MySQL kullanılıp kullanılmayacağını belirle
     * @return MySQL kullanılacaksa true, SQLite kullanılacaksa false
     */
    public boolean useMySQL() {
        return config.getBoolean("database.use-mysql", DEFAULT_USE_MYSQL);
    }
    
    /**
     * MySQL veritabanı bilgilerini al
     * @return MySQL bağlantı bilgileri
     */
    public MySQLConfig getMySQLConfig() {
        String host = config.getString("database.mysql.host", DEFAULT_MYSQL_HOST);
        int port = config.getInt("database.mysql.port", DEFAULT_MYSQL_PORT);
        String database = config.getString("database.mysql.database", DEFAULT_MYSQL_DATABASE);
        String username = config.getString("database.mysql.username", DEFAULT_MYSQL_USERNAME);
        String password = config.getString("database.mysql.password", DEFAULT_MYSQL_PASSWORD);
        
        return new MySQLConfig(host, port, database, username, password);
    }
    
    /**
     * Maden dağılım oranlarını al
     * @return Maden dağılım oranları haritası
     */
    public Map<String, Double> getOreDistribution() {
        Map<String, Double> distribution = new HashMap<>();
        
        if (config.contains("ore-distribution")) {
            for (String key : config.getConfigurationSection("ore-distribution").getKeys(false)) {
                double value = config.getDouble("ore-distribution." + key, 0.0);
                distribution.put(key, value);
            }
        } else {
            distribution.putAll(DEFAULT_ORE_DISTRIBUTION);
        }
        
        return distribution;
    }
    
    /**
     * Maden damar boyutu aralığını al (ör: 6-10 -> [6,10])
     */
    public int[] getVeinSizeRange(String oreName) {
        if (config.contains("veins." + oreName)) {
            String range = config.getString("veins." + oreName);
            if (range != null && range.contains("-")) {
                String[] parts = range.split("-");
                try {
                    int min = Integer.parseInt(parts[0].trim());
                    int max = Integer.parseInt(parts[1].trim());
                    return new int[]{min, max};
                } catch (NumberFormatException ignored) {}
            }
        }
        // Varsayılan: 1-1 (tekli damar)
        return new int[]{1, 1};
    }
    
    /**
     * MySQL konfigürasyon sınıfı
     */
    public static class MySQLConfig {
        private final String host;
        private final int port;
        private final String database;
        private final String username;
        private final String password;
        
        public MySQLConfig(String host, int port, String database, String username, String password) {
            this.host = host;
            this.port = port;
            this.database = database;
            this.username = username;
            this.password = password;
        }
        
        public String getHost() {
            return host;
        }
        
        public int getPort() {
            return port;
        }
        
        public String getDatabase() {
            return database;
        }
        
        public String getUsername() {
            return username;
        }
        
        public String getPassword() {
            return password;
        }
    }
} 