package com.hantixray.webhook;

import club.minnced.discord.webhook.WebhookClient;
import club.minnced.discord.webhook.WebhookClientBuilder;
import club.minnced.discord.webhook.send.WebhookEmbed;
import club.minnced.discord.webhook.send.WebhookEmbedBuilder;
import club.minnced.discord.webhook.send.WebhookMessageBuilder;
import com.hantixray.HantiXray;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import java.util.logging.Logger;

import java.awt.Color;
import java.time.Instant;

public class WebhookManager {
    
    private final HantiXray plugin;
    private final Logger logger;
    private WebhookClient webhookClient;
    
    public WebhookManager(HantiXray plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        setupWebhook();
    }
    
    /**
     * Discord webhook'unu ayarla
     */
    private void setupWebhook() {
        String webhookUrl = plugin.getConfigManager().getDiscordWebhookUrl();
        
        if (webhookUrl == null || webhookUrl.isEmpty()) {
            logger.warning("Discord webhook URL is not configured. Notifications are disabled.");
            return;
        }
        
        try {
            webhookClient = new WebhookClientBuilder(webhookUrl).build();
            logger.info("Discord webhook connection established successfully.");
        } catch (Exception e) {
            logger.severe("Error establishing Discord webhook connection: " + e.getMessage());
        }
    }
    
    /**
     * Send suspicious activity alert
     * @param player Suspicious player
     * @param location Detection location
     * @param oreType Ore type
     * @param suspicionScore Current suspicion score
     */
    public void sendSuspiciousActivityAlert(Player player, Location location, String oreType, int suspicionScore) {
        if (webhookClient == null) {
            return;
        }
        
        try {
            WebhookEmbed embed = new WebhookEmbedBuilder()
                    .setColor(Color.RED.getRGB())
                    .setTitle(new WebhookEmbed.EmbedTitle("⚠️ Suspicious X-Ray Activity", null))
                    .setDescription("A player mined a fake ore block, possibly using x-ray hacks.")
                    .addField(new WebhookEmbed.EmbedField(true, "Player", player.getName()))
                    .addField(new WebhookEmbed.EmbedField(true, "UUID", player.getUniqueId().toString()))
                    .addField(new WebhookEmbed.EmbedField(true, "IP Address", player.getAddress().getAddress().getHostAddress()))
                    .addField(new WebhookEmbed.EmbedField(true, "World", location.getWorld().getName()))
                    .addField(new WebhookEmbed.EmbedField(true, "Coordinates", String.format("X: %d, Y: %d, Z: %d", 
                            location.getBlockX(), location.getBlockY(), location.getBlockZ())))
                    .addField(new WebhookEmbed.EmbedField(true, "Ore Type", oreType))
                    .addField(new WebhookEmbed.EmbedField(true, "Suspicion Score", suspicionScore + "/" + 
                            plugin.getConfigManager().getSuspicionThreshold()))
                    .setFooter(new WebhookEmbed.EmbedFooter("HantiXray Anti-Xray Plugin", null))
                    .setTimestamp(Instant.now())
                    .build();
            
            webhookClient.send(embed);
            logger.info("Discord notification sent: Suspicious activity for " + player.getName());
        } catch (Exception e) {
            logger.severe("Error sending Discord webhook notification: " + e.getMessage());
        }
    }
    
    /**
     * Send auto-ban alert
     * @param player Banned player
     * @param suspicionScore Suspicion score
     */
    public void sendAutoBanAlert(Player player, int suspicionScore) {
        if (webhookClient == null) {
            return;
        }
        
        try {
            WebhookEmbed embed = new WebhookEmbedBuilder()
                    .setColor(new Color(128, 0, 0).getRGB()) // Dark red
                    .setTitle(new WebhookEmbed.EmbedTitle("🚫 X-Ray Automatic Ban", null))
                    .setDescription("A player has been automatically banned for using x-ray hacks.")
                    .addField(new WebhookEmbed.EmbedField(true, "Player", player.getName()))
                    .addField(new WebhookEmbed.EmbedField(true, "UUID", player.getUniqueId().toString()))
                    .addField(new WebhookEmbed.EmbedField(true, "IP Address", player.getAddress().getAddress().getHostAddress()))
                    .addField(new WebhookEmbed.EmbedField(true, "Suspicion Score", suspicionScore + "/" + 
                            plugin.getConfigManager().getSuspicionThreshold()))
                    .addField(new WebhookEmbed.EmbedField(false, "Ban Reason", 
                            "Using X-Ray hacks - Fake ores detected"))
                    .setFooter(new WebhookEmbed.EmbedFooter("HantiXray Anti-Xray Plugin", null))
                    .setTimestamp(Instant.now())
                    .build();
            
            webhookClient.send(embed);
            logger.info("Discord notification sent: " + player.getName() + " has been automatically banned.");
        } catch (Exception e) {
            logger.severe("Error sending Discord webhook notification: " + e.getMessage());
        }
    }
    
    /**
     * Close webhook client
     */
    public void shutdown() {
        if (webhookClient != null) {
            webhookClient.close();
            logger.info("Discord webhook connection closed.");
        }
    }
} 